const { convertDateToGetTime } = require("../js/convertDateToGetTime");

test("Test Data fetching method", () => {
  expect(convertDateToGetTime).toBeDefined();
});
